# pip install websocket-client keyboard
import websocket
import json
import keyboard
import time

def send_command(cmd):
    server_ip = "2001:288:6004:17:fff1:cd25:0:a039"   # 換成你的 IPv6
    server_port = 8081
    ws_url = f"ws://[{server_ip}]:{server_port}"

    try:
        ws = websocket.create_connection(ws_url)
        message = json.dumps({"cmd": cmd})
        ws.send(message)
        result = ws.recv()
        print(f"Sent command: {cmd} | Received: {result}")
        ws.close()
    except Exception as e:
        print(f"Failed to send command {cmd}: {e}")

def main():
    print("按 W（上一個）、S（下一個）。ESC 離開。")
    while True:
        try:
            if keyboard.is_pressed("w"):
                send_command("W")
                while keyboard.is_pressed("w"):
                    time.sleep(0.1)  # 等待放開避免重複送
            elif keyboard.is_pressed("s"):
                send_command("S")
                while keyboard.is_pressed("s"):
                    time.sleep(0.1)
            elif keyboard.is_pressed("esc"):
                print("Exiting...")
                break
        except Exception as e:
            print(f"Error: {e}")
            break

if __name__ == "__main__":
    main()
